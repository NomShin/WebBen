﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcMovie.Controllers
{
    public class HelloworldController : Controller
    {
        // GET: Helloworld
        public ActionResult Index()
        {
            return View();
        }

        //// GET: Helloworld
        //public string Index()
        //{
        //    return "Hellow World...";
        //}


        //// GET: Helloworld/Welcome
        //public string Welcome()
        //{
        //    return "ここは Weeeeeeeelcome";
        //}


        // GET: Helloworld/Welcome
        //public string Welcome(string name, int numTimes = 1)
        public ActionResult Welcome(string name, int numTimes = 1)
        {
            //return "ここは Weeeeeeeelcome";
            //return HttpUtility.HtmlEncode("ここは Weeeeeeeelcome: へろー" + name + "様. numTimes = " + numTimes);

            ViewBag.Message = "ハロー " + name;
            ViewBag.NumTimes = numTimes;
            return View();
        }


        // GET: Helloworld/        public string Login(string name, int ID = 1)

        public string Login(string name, int ID = 1)
        {
            return HttpUtility.HtmlEncode("Hello " + name + " ID:" + ID);
        }
    }
}