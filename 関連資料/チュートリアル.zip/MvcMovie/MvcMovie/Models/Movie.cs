﻿using System;
using System.Data.Entity;   //追加
using System.ComponentModel.DataAnnotations;   //追加

namespace MvcMovie.Models
{
    public class Movie
    {
        public int ID { set; get; }

        [Display(Name = "タイトル")]
        public string Title { set; get; }

        [Display(Name ="リリース日")]
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { set; get; }

        [Display(Name = "ジャンル")]
        public string Genre { set; get; }

        [Display(Name = "価格")]
        [DataType(DataType.Currency)]
        public decimal Price { set; get; }
    }

    public class MovieDBContext : DbContext
    {
        public DbSet<Movie> Movies { set; get; }
    }
}